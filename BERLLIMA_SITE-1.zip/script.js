document.getElementById('orderForm').addEventListener('submit', function(e){
  e.preventDefault();
  const name=document.getElementById('name').value.trim();
  const network=document.getElementById('network').value;
  const service=document.getElementById('service').value.trim();
  const link=document.getElementById('link').value.trim();
  const text=`Bonjour BERLLIMA, je souhaite passer une commande.%0A%0ANom : ${encodeURIComponent(name)}%0ARéseau : ${encodeURIComponent(network)}%0AService : ${encodeURIComponent(service)}%0ALien : ${encodeURIComponent(link)}`;
  const box=document.getElementById('result');
  box.hidden=false;
  box.innerHTML=`<b>Commande préparée ✅</b><p>Il reste à configurer le numéro WhatsApp/Orange Money/MTN Money pour finaliser automatiquement le paiement.</p><a class="btn" href="https://wa.me/?text=${text}" target="_blank">Envoyer la commande sur WhatsApp</a>`;
});