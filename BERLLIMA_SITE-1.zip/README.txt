SITE BERLLIMA — version de départ
1. Ouvrir index.html pour tester le site.
2. Pour le mettre en ligne, envoyer ces fichiers sur un hébergeur de site statique.
3. Avant les paiements réels, remplacer les coordonnées de contact et configurer un vrai moyen de paiement.
